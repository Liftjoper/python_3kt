def array_diff(a: list, b: list) -> list:
    """Решение для Задачи 1"""
    return list(filter(lambda element: element not in b, a))




def sum_pairs(nums: list, sum: int) -> list:
    """Решение для Задачи 2"""
    seen_numbers = {}
    for position, current_num in enumerate(nums):
        needed_num = sum - current_num
        if needed_num in seen_numbers:
            return [needed_num, current_num]
        seen_numbers[current_num] = position
    return None



def remove_duplicate_ids(obj: dict) -> dict:
    """Решение для Задачи 3"""
    ids_sorted = sorted(obj.keys(), key=lambda x: int(x), reverse=True)
    already_seen = []
    final_result = {}
    
    for current_id in ids_sorted:
        current_values = obj[current_id]
        unique_for_this_id = []
        
        for val in current_values:
            if val not in already_seen:
                unique_for_this_id.append(val)
                already_seen.append(val)
        
        final_result[current_id] = unique_for_this_id
    
    return final_result




def lazy(threshold: int):
    """Решение для Задачи 4"""
    def decorator(original_function):
        execution_counter = 0
        
        def wrapper(*args, **kwargs):
            nonlocal execution_counter
            execution_counter += 1
            
            if threshold > 0:
                if threshold == 1:
                    return original_function(*args, **kwargs)
                # Для n>1: выполняем на 1-м, (n+1)-м, (2n+1)-м...
                if execution_counter % threshold == 1:
                    return original_function(*args, **kwargs)
                return None
            elif threshold < 0:
                skip_frequency = -threshold
                if execution_counter % skip_frequency == 0:
                    return None
                return original_function(*args, **kwargs)
            else:  
                return original_function(*args, **kwargs)
        
        return wrapper
    return decorator